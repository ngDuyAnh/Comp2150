
Duy Anh Nguyen 7892957
Comp 2150 Assignment 2

To compile and run the code...
Please use command to compile: make A2main
Please use command to run test data: main A2-official-data.txt



To run the test for Priority Queue data structure.
Please use command to compile: make TestFile
Please use command to run test data: test
