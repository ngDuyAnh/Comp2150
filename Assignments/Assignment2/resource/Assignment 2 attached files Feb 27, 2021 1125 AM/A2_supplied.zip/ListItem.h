#pragma once

class ListItem {
public:
	virtual int compareTo(ListItem *other) = 0;
}; // class ListItem
