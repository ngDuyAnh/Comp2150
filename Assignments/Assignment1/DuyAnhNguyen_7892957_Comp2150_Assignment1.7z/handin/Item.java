
/*
Duy Anh Nguyen 7892957
January 31, 2021
Item.java
public abstract class Item implements Printable
Parent call act as storage for item in list.
*/

public abstract class Item implements Printable
{
    /* Empty */
}
