# WikiManager
# Instructions to compile and run the application WikiManager.

```
Please use the Makefile for your convinience.

Running the application.
To compile the application, please use this command...
	make WikiManagerCompile
To run the application, please use this command...
	make WikiManager
Data files are in the folder...
	sample_data.txt
	sample.txt
	a1_test_data.txt

Running the unit test.
To compile the test, please use this command...
	make WikiManagerTestCompile
To run the test, please use this command...
	make WikiManagerTest


There is a zip file that you can use IntelliJ to view the project.

All output files from test and provided data will be in the output folder.
```

